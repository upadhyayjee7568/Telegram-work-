#!/bin/bash
# =========================================================
#   FREE MONEY EARNING ADDA (FMEA) BOT - Setup Script
# =========================================================

echo "======================================================"
echo "  🚀 FMEA Bot - Auto Setup Script"
echo "======================================================"

# Install Python dependencies
echo "📦 Installing dependencies..."
pip install -r requirements.txt

echo ""
echo "✅ Setup Complete!"
echo ""
echo "📋 NEXT STEPS:"
echo "1. Edit config.py and add your BOT_TOKEN"
echo "2. Add your Telegram numeric ID in ADMIN_IDS"
echo "3. Set your CHANNEL_USERNAME"
echo "4. Run: python bot.py"
echo ""
echo "======================================================"
