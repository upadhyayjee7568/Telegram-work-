"""
=============================================================
  FREE MONEY EARNING ADDA (FMEA) BOT - Configuration File
=============================================================
  Developer: FMEA Admin System
  Version: 2.0 Professional
=============================================================
"""

# ⚡ BOT TOKEN - BotFather se milega
BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

# 📢 CHANNEL USERNAME - jo channel banao uska username
CHANNEL_USERNAME = "@FreeMoneyEarningAdda"  # apna channel username daalo

# 👑 ADMIN TELEGRAM USER IDs (aapki ID)
ADMIN_IDS = [
    123456789,  # ← Yahan apni Telegram numeric ID daalni hai
]

# 📊 DATABASE FILE
DB_FILE = "fmea_database.db"

# ⏰ SCHEDULER TIMEZONE
TIMEZONE = "Asia/Kolkata"

# 🎨 BOT NAME & BRANDING
BOT_NAME = "Free Money 💰 Earning Adda"
BOT_USERNAME = "@FMEAbot"  # apna bot username
BOT_VERSION = "2.0 Pro"

# 🔗 REFERRAL SYSTEM
REFERRAL_BONUS = 10  # points per referral
JOIN_BONUS = 5       # points when user joins

# 📅 AUTO POST TIMES (24-hour format IST)
AUTO_POST_TIMES = ["09:00", "14:00", "20:00"]  # Din me 3 baar auto post

# 🌐 WEBSITE/LINKS
SUPPORT_LINK = "https://t.me/amanjee7568"
CHANNEL_LINK = "https://t.me/FreeMoneyEarningAdda"

# 💬 WELCOME MESSAGE
WELCOME_TEXT = """
🎉 *स्वागत है {name}!*

╔══════════════════════════╗
║  💰 *Free Money Earning Adda* 💰  ║
╚══════════════════════════╝

✨ *आपका FMEA परिवार में स्वागत है!*

📌 *यहाँ आपको मिलेगा:*
├ 💸 Daily Earning Tips
├ 📱 Online Money Making Methods
├ 🎯 Investment Ideas
├ 💡 Business Tips
├ 🔥 Exclusive Offers & Deals
└ 📊 Market Updates

🎁 *Join Bonus:* +{bonus} Points मिले!

👇 *नीचे दिए बटन से शुरू करें:*
"""

# 📢 PROMOTION MESSAGES
PROMO_MESSAGES = [
    """
🔥 *FREE MONEY EARNING ADDA*

💰 हर रोज़ कमाओ घर बैठे!
📱 100% Free Methods
✅ Verified & Trusted

👉 Join करो अभी: {channel_link}
📲 Share करो दोस्तों के साथ!

#FreeMoneyEarning #OnlineEarning #FMEA
    """,
    """
⚡ *Daily Earning Update - FMEA*

🎯 आज का टॉपिक: Online Earning
💡 नए-नए तरीके सीखो
🚀 अपनी Income बढ़ाओ

📢 Channel: {channel_link}
💬 Support: {support_link}

🔔 Notification ON करो!
    """,
    """
💎 *EXCLUSIVE - FMEA Members Only*

🏆 Top Earning Methods:
├ ✅ Freelancing
├ ✅ Affiliate Marketing  
├ ✅ Online Trading Tips
├ ✅ App से कमाई
└ ✅ YouTube & Content

📲 Join Now: {channel_link}
    """
]
