#!/usr/bin/env python3
"""
Quick test script to verify bot configuration
"""
import sys
import os

def test_config():
    print("🔍 Testing Configuration...")
    
    try:
        from config import BOT_TOKEN, CHANNEL_USERNAME, ADMIN_IDS, BOT_NAME
        
        issues = []
        
        if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
            issues.append("❌ BOT_TOKEN not set! Edit config.py")
        else:
            print(f"✅ BOT_TOKEN: Set (starts with {BOT_TOKEN[:10]}...)")
        
        if 123456789 in ADMIN_IDS:
            issues.append("❌ ADMIN_IDS not set! Add your real Telegram ID")
        else:
            print(f"✅ ADMIN_IDS: {ADMIN_IDS}")
        
        if CHANNEL_USERNAME == "@FreeMoneyEarningAdda":
            print(f"⚠️  CHANNEL_USERNAME: {CHANNEL_USERNAME} (verify this is correct)")
        else:
            print(f"✅ CHANNEL_USERNAME: {CHANNEL_USERNAME}")
        
        if issues:
            print("\n⚠️  ISSUES FOUND:")
            for issue in issues:
                print(f"   {issue}")
            return False
        else:
            print("\n✅ All configurations look good!")
            return True
            
    except ImportError as e:
        print(f"❌ Import error: {e}")
        return False

def test_database():
    print("\n🗄️  Testing Database...")
    try:
        from database import init_database, get_user_stats
        init_database()
        stats = get_user_stats()
        print(f"✅ Database: Working (Users: {stats['total']})")
        return True
    except Exception as e:
        print(f"❌ Database error: {e}")
        return False

def test_telegram():
    print("\n📱 Testing Telegram Connection...")
    try:
        import asyncio
        from telegram import Bot
        from config import BOT_TOKEN
        
        if BOT_TOKEN == "YOUR_BOT_TOKEN_HERE":
            print("⚠️  Skipping Telegram test (token not set)")
            return False
        
        async def check():
            bot = Bot(BOT_TOKEN)
            me = await bot.get_me()
            print(f"✅ Bot: @{me.username} ({me.first_name})")
            return True
        
        return asyncio.run(check())
    except Exception as e:
        print(f"❌ Telegram error: {e}")
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("  FMEA Bot - Configuration Test")
    print("=" * 50)
    
    config_ok = test_config()
    db_ok = test_database()
    tg_ok = test_telegram()
    
    print("\n" + "=" * 50)
    print("📊 Test Results:")
    print(f"  Config:   {'✅' if config_ok else '❌'}")
    print(f"  Database: {'✅' if db_ok else '❌'}")
    print(f"  Telegram: {'✅' if tg_ok else '⚠️'}")
    print("=" * 50)
    
    if config_ok and db_ok:
        print("\n🚀 Bot is ready to run!")
        print("   Command: python bot.py")
    else:
        print("\n⚠️  Fix issues above before running bot")
